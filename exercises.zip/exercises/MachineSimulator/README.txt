* Run the python file runSimulation.py to invoke the simulation

* Enter Number of Machines , Failure percentage and time to recovery followed by spaces
    Example :
    50 10 5
* The enter any of the following choices to get its respective functionality as asked in question

1.failure_trend
2. is_machine_alive m_4
3. remove_machines m_4
4. num_machines_alive
5. add_machines m_1,m_3
6. Type quit to exit
