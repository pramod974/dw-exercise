import machineSimulator as ms
ob = ms.heart_sim()
ob.execute()