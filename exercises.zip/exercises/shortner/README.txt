Author Pramodkumar

* The shortner Class has two methods shortenfile and shorten.
* The Shortenfile method take a file containing long URL string and returns a orginal list of  URL processed and Short URL
        Example 1: shortner.shortenfile(os.getcwd()+"/urls.txt")

* The Shorten takes a string URL input and returns the short URL
        Example 2: shortner.shorten("https://www.google.co.in/search?q=pyspark+external+sort&oq=pyspark+external+sort+&aqs=chrome..69i57.10233j0j7&sourceid=chrome&ie=UTF-8")

* Run useShortner.py to test